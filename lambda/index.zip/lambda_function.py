import json, os
from slack import WebClient
from slack.errors import SlackApiError

client = WebClient(token=os.environ['SLACK_VERIFICATION_TOKEN'])
apiurl = os.environ['SELF_API_URL']

# test text, but more!



def lambda_handler(event, context):
    if 'X-Slack-Retry-Num' in event['headers']:
        slk_retry = event['headers']['X-Slack-Retry-Num']
        return 200
    
    try:
        data = json.loads(event["body"])["event"]
        file_id = data["file_id"]
        
        filedata = client.files_info(
        channel=data["channel_id"],
        file=file_id
        )["file"]
        
        filetype = filedata["filetype"]
        
        if filetype == "pdf" and data["type"] in ["file_created", "file_shared"]:
            msg = {
                "response_url":"https://7xi2tg83ag.execute-api.us-east-1.amazonaws.com/ssi-test/paper-a-day",
                "channel": data["channel_id"],
                "attachments": [
                    {
                        "text": "Is this ({}) a paper you (<@{}>) read?".format(filedata["name"], data["user_id"]),
                        "fallback": "The office is now closed. [Closes window on your hands.]",
                        "callback_id": "read-paper",
                        "link_names": True,
                        "color": "#3AA3E3",
                        "attachment_type": "default",
                        "actions": [
                            {
                                "name": "yes",
                                "text": "Yes!",
                                "style": "danger",
                                "type": "button",
                                "value": file_id,
                                "confirm": {
                                    "title": "Don't be a weasle.",
                                    "text": "It's better to not accomplish your goals than to be a liar!",
                                    "ok_text": "I PROMISE I READ IT!",
                                    "dismiss_text": "I did not read it."
                                }
                            },
                            {
                                "name": "no",
                                "text": "No.",
                                "type": "button",
                                "value": "NO"
                            }
                        ]
                    }
                ]
            }
            
            
            client.api_call("chat.postMessage", json=msg)
        return 200
    except Exception as e:
        import base64
        from urllib import parse as urlparse
        import boto3
        if "body" in event:
            body = event["body"]
            body = base64.b64decode(body).decode('utf-8')
            body = urlparse.parse_qs(body)
            body = json.loads(body["payload"][0])
            try:
                client.api_call("chat.delete", json={"channel":body["channel"]["id"], "ts": body["message_ts"]})
            except Exception as e:
                pass
            
            if not body["actions"][0]["value"] == "NO":
                filedata = client.files_info(
                channel=body["channel"]["id"],
                file=body["actions"][0]["value"]
                )["file"]
                
                client.chat_postMessage(channel=body["channel"]["id"], 
                text="Okay, I'll mark {} down as having read {}.".format(body["user"]["name"], filedata["name"]))
                
                table = boto3.resource('dynamodb').Table('paper-a-day_papers')
                response = table.put_item(
                   Item={
                        'id': filedata["id"],
                        'user': body["user"]["name"],
                        'channel': body["channel"]["id"],
                        'paper': filedata["name"],
                        'filedata': str(filedata)
                    }
                )
            
            
                if str(body["user"]["name"]) in ["uttmark"]:
                    import requests
                    requests.post("https://maker.ifttt.com/trigger/slack_paper_upload/with/key/bNpead6Zfy1AhFv201SYXTq49RBnEgTQ-ILg-1_LiRW",
                    data={"value1":str(filedata["name"]), "value2":"", "value3":""})
                    client.chat_postMessage(channel=body["channel"]["id"], 
                    text="Oh! You have a Beeminder account. Cute. I sent them a message.")
            return {'statusCode': 200}
        
    return {
        'statusCode': 200,
        'body': json.dumps('No actions were taken :('),
        'event': event
    }

